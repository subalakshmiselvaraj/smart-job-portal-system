const Application = require("../models/Application");
const Job = require("../models/Job");

// @route   POST /api/apply
// @access  Private (user)
exports.applyToJob = async (req, res, next) => {
  try {
    const { jobId, coverNote } = req.body;

    if (!jobId) {
      return res.status(400).json({ success: false, message: "jobId is required" });
    }

    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found" });
    }

    if (req.user.role !== "user") {
      return res.status(403).json({ success: false, message: "Only job seekers can apply to jobs" });
    }

    const existing = await Application.findOne({ userId: req.user._id, jobId });
    if (existing) {
      return res.status(400).json({ success: false, message: "You have already applied to this job" });
    }

    const application = await Application.create({
      userId: req.user._id,
      jobId,
      coverNote: coverNote || "",
    });

    job.applicantsCount += 1;
    await job.save();

    res.status(201).json({
      success: true,
      message: "Application submitted successfully",
      application,
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/applications/user
// @access  Private (user)
exports.getUserApplications = async (req, res, next) => {
  try {
    const applications = await Application.find({ userId: req.user._id })
      .populate({
        path: "jobId",
        select: "title company location jobType salary skills",
      })
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: applications.length, applications });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/applications/job/:id
// @access  Private (recruiter who owns job / admin)
exports.getJobApplications = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ success: false, message: "Not authorized to view these applications" });
    }

    const applications = await Application.find({ jobId: req.params.id })
      .populate("userId", "name email skills location headline")
      .sort({ createdAt: -1 });

    res.status(200).json({ success: true, count: applications.length, applications });
  } catch (err) {
    next(err);
  }
};

// @route   PUT /api/applications/:id/status
// @access  Private (recruiter who owns job / admin)
exports.updateApplicationStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const validStatuses = ["pending", "shortlisted", "accepted", "rejected"];

    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: "Invalid status value" });
    }

    const application = await Application.findById(req.params.id).populate("jobId");
    if (!application) {
      return res.status(404).json({ success: false, message: "Application not found" });
    }

    if (application.jobId.postedBy.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ success: false, message: "Not authorized to update this application" });
    }

    application.status = status;
    await application.save();

    res.status(200).json({ success: true, message: "Application status updated", application });
  } catch (err) {
    next(err);
  }
};
