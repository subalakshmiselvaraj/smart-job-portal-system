const Job = require("../models/Job");
const Application = require("../models/Application");

// @route   GET /api/jobs
// @access  Public
// Supports: ?search=&location=&skills=&jobType=&page=&limit=
exports.getJobs = async (req, res, next) => {
  try {
    const { search, location, skills, jobType, page = 1, limit = 9 } = req.query;

    const query = { isActive: true };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: "i" } },
        { company: { $regex: search, $options: "i" } },
        { skills: { $regex: search, $options: "i" } },
      ];
    }

    if (location) {
      query.location = { $regex: location, $options: "i" };
    }

    if (skills) {
      const skillsArray = skills.split(",").map((s) => s.trim());
      query.skills = { $in: skillsArray.map((s) => new RegExp(s, "i")) };
    }

    if (jobType) {
      query.jobType = jobType;
    }

    const pageNum = Math.max(parseInt(page) || 1, 1);
    const limitNum = Math.max(parseInt(limit) || 9, 1);
    const skip = (pageNum - 1) * limitNum;

    const [jobs, total] = await Promise.all([
      Job.find(query)
        .populate("postedBy", "name company")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limitNum),
      Job.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      count: jobs.length,
      total,
      totalPages: Math.ceil(total / limitNum),
      currentPage: pageNum,
      jobs,
    });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/jobs/:id
// @access  Public
exports.getJobById = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id).populate("postedBy", "name company email");
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found" });
    }
    res.status(200).json({ success: true, job });
  } catch (err) {
    next(err);
  }
};

// @route   POST /api/jobs
// @access  Private (recruiter/admin)
exports.createJob = async (req, res, next) => {
  try {
    const { title, company, description, skills, location, jobType, experience, salary } = req.body;

    if (!title || !company || !description || !location) {
      return res.status(400).json({
        success: false,
        message: "Please provide title, company, description and location",
      });
    }

    const job = await Job.create({
      title,
      company,
      description,
      skills: Array.isArray(skills) ? skills : (skills || "").split(",").map((s) => s.trim()).filter(Boolean),
      location,
      jobType,
      experience,
      salary,
      postedBy: req.user._id,
    });

    res.status(201).json({ success: true, message: "Job posted successfully", job });
  } catch (err) {
    next(err);
  }
};

// @route   PUT /api/jobs/:id
// @access  Private (recruiter who owns job / admin)
exports.updateJob = async (req, res, next) => {
  try {
    let job = await Job.findById(req.params.id);
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ success: false, message: "Not authorized to edit this job" });
    }

    const updates = { ...req.body };
    if (updates.skills && !Array.isArray(updates.skills)) {
      updates.skills = updates.skills.split(",").map((s) => s.trim()).filter(Boolean);
    }

    job = await Job.findByIdAndUpdate(req.params.id, updates, { new: true, runValidators: true });

    res.status(200).json({ success: true, message: "Job updated successfully", job });
  } catch (err) {
    next(err);
  }
};

// @route   DELETE /api/jobs/:id
// @access  Private (recruiter who owns job / admin)
exports.deleteJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) {
      return res.status(404).json({ success: false, message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString() && req.user.role !== "admin") {
      return res.status(403).json({ success: false, message: "Not authorized to delete this job" });
    }

    await Application.deleteMany({ jobId: job._id });
    await job.deleteOne();

    res.status(200).json({ success: true, message: "Job deleted successfully" });
  } catch (err) {
    next(err);
  }
};

// @route   GET /api/jobs/recruiter/my-jobs
// @access  Private (recruiter/admin)
exports.getMyJobs = async (req, res, next) => {
  try {
    const jobs = await Job.find({ postedBy: req.user._id }).sort({ createdAt: -1 });
    res.status(200).json({ success: true, count: jobs.length, jobs });
  } catch (err) {
    next(err);
  }
};
