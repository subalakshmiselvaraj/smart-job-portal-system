const express = require("express");
const router = express.Router();
const {
  applyToJob,
  getUserApplications,
  getJobApplications,
  updateApplicationStatus,
} = require("../controllers/applicationController");
const { protect, authorize } = require("../middleware/auth");

router.post("/apply", protect, authorize("user"), applyToJob);
router.get("/applications/user", protect, authorize("user"), getUserApplications);
router.get("/applications/job/:id", protect, authorize("recruiter", "admin"), getJobApplications);
router.put("/applications/:id/status", protect, authorize("recruiter", "admin"), updateApplicationStatus);

module.exports = router;
