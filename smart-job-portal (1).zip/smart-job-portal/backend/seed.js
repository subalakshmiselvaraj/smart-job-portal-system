require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("./config/db");
const User = require("./models/User");
const Job = require("./models/Job");
const Application = require("./models/Application");

const seed = async () => {
  await connectDB();

  console.log("🧹 Clearing existing data...");
  await User.deleteMany({});
  await Job.deleteMany({});
  await Application.deleteMany({});

  console.log("👤 Creating demo users...");
  const admin = await User.create({
    name: "Admin User",
    email: "admin@jobportal.com",
    password: "admin123",
    role: "admin",
    avatarColor: "#6366f1",
  });

  const recruiter1 = await User.create({
    name: "Priya Sharma",
    email: "recruiter@techcorp.com",
    password: "recruiter123",
    role: "recruiter",
    company: "TechCorp Solutions",
    avatarColor: "#8b5cf6",
  });

  const recruiter2 = await User.create({
    name: "Arjun Mehta",
    email: "recruiter@innovate.com",
    password: "recruiter123",
    role: "recruiter",
    company: "Innovate Labs",
    avatarColor: "#ec4899",
  });

  const jobseeker = await User.create({
    name: "Karthik Raja",
    email: "user@example.com",
    password: "user1234",
    role: "user",
    headline: "Full Stack Developer",
    location: "Bengaluru, India",
    skills: ["React", "Node.js", "MongoDB", "JavaScript"],
    avatarColor: "#10b981",
  });

  console.log("💼 Creating demo jobs...");
  const jobsData = [
    {
      title: "Senior Frontend Developer",
      company: "TechCorp Solutions",
      description:
        "We are looking for a Senior Frontend Developer to join our growing engineering team. You will be responsible for building beautiful, performant user interfaces using React, collaborating closely with designers and backend engineers to ship features that delight our users. You should have a strong eye for detail and a passion for clean, maintainable code.",
      skills: ["React", "TypeScript", "Tailwind CSS", "Redux"],
      location: "Bengaluru, India",
      jobType: "Full-time",
      experience: "3-5 years",
      salary: { min: 1200000, max: 2200000 },
      postedBy: recruiter1._id,
    },
    {
      title: "Backend Engineer (Node.js)",
      company: "TechCorp Solutions",
      description:
        "Join our backend team to design and build scalable REST APIs and microservices powering our core platform. Experience with Node.js, Express, and MongoDB is essential. You'll work on system architecture, performance optimization, and mentoring junior engineers.",
      skills: ["Node.js", "Express", "MongoDB", "Docker"],
      location: "Hyderabad, India",
      jobType: "Full-time",
      experience: "2-4 years",
      salary: { min: 1000000, max: 1800000 },
      postedBy: recruiter1._id,
    },
    {
      title: "Product Designer (UI/UX)",
      company: "Innovate Labs",
      description:
        "Innovate Labs is seeking a talented Product Designer to craft delightful, intuitive experiences across our suite of products. You'll own the design process end-to-end, from research and wireframes to high-fidelity prototypes, working closely with product and engineering.",
      skills: ["Figma", "UI Design", "Prototyping", "Design Systems"],
      location: "Remote",
      jobType: "Remote",
      experience: "2-5 years",
      salary: { min: 900000, max: 1600000 },
      postedBy: recruiter2._id,
    },
    {
      title: "Data Scientist",
      company: "Innovate Labs",
      description:
        "We're hiring a Data Scientist to drive insights from large datasets, build predictive models, and partner with product teams to inform decisions. Strong foundation in statistics, Python, and machine learning frameworks required.",
      skills: ["Python", "Machine Learning", "SQL", "Pandas"],
      location: "Pune, India",
      jobType: "Full-time",
      experience: "1-3 years",
      salary: { min: 800000, max: 1500000 },
      postedBy: recruiter2._id,
    },
    {
      title: "DevOps Engineer",
      company: "TechCorp Solutions",
      description:
        "Looking for a DevOps Engineer to build and maintain our CI/CD pipelines, manage cloud infrastructure on AWS, and ensure high availability of our production systems. Kubernetes and Terraform experience preferred.",
      skills: ["AWS", "Kubernetes", "Terraform", "CI/CD"],
      location: "Chennai, India",
      jobType: "Full-time",
      experience: "3-6 years",
      salary: { min: 1400000, max: 2400000 },
      postedBy: recruiter1._id,
    },
    {
      title: "Software Engineering Intern",
      company: "Innovate Labs",
      description:
        "Great opportunity for students or recent graduates to gain hands-on experience working on real production systems. You'll be paired with a mentor and contribute to live projects using modern web technologies.",
      skills: ["JavaScript", "React", "Git", "Problem Solving"],
      location: "Remote",
      jobType: "Internship",
      experience: "Freshers",
      salary: { min: 240000, max: 400000 },
      postedBy: recruiter2._id,
    },
    {
      title: "Mobile App Developer (React Native)",
      company: "TechCorp Solutions",
      description:
        "Build cross-platform mobile applications used by millions of users. You'll work with React Native, integrate with REST/GraphQL APIs, and optimize app performance across iOS and Android.",
      skills: ["React Native", "JavaScript", "REST APIs", "Firebase"],
      location: "Mumbai, India",
      jobType: "Full-time",
      experience: "2-4 years",
      salary: { min: 1000000, max: 1900000 },
      postedBy: recruiter1._id,
    },
    {
      title: "Marketing Manager - Growth",
      company: "Innovate Labs",
      description:
        "Drive user acquisition and retention strategies across digital channels. You'll own campaign performance, run experiments, and partner with the product team to improve conversion funnels.",
      skills: ["Digital Marketing", "SEO", "Analytics", "Growth Strategy"],
      location: "Delhi, India",
      jobType: "Full-time",
      experience: "3-5 years",
      salary: { min: 900000, max: 1700000 },
      postedBy: recruiter2._id,
    },
    {
      title: "QA Automation Engineer",
      company: "TechCorp Solutions",
      description:
        "Join our quality engineering team to design, build and maintain automated test suites. You'll work closely with developers to ensure high quality releases through robust testing practices.",
      skills: ["Selenium", "Cypress", "JavaScript", "Test Automation"],
      location: "Bengaluru, India",
      jobType: "Contract",
      experience: "2-3 years",
      salary: { min: 700000, max: 1200000 },
      postedBy: recruiter1._id,
    },
  ];

  const jobs = await Job.insertMany(jobsData);

  console.log("📝 Creating demo applications...");
  await Application.create({
    userId: jobseeker._id,
    jobId: jobs[0]._id,
    status: "pending",
    coverNote: "I'm excited to apply for this role given my experience with React and TypeScript.",
  });
  jobs[0].applicantsCount += 1;
  await jobs[0].save();

  await Application.create({
    userId: jobseeker._id,
    jobId: jobs[1]._id,
    status: "shortlisted",
    coverNote: "I have 3 years of Node.js experience building scalable APIs.",
  });
  jobs[1].applicantsCount += 1;
  await jobs[1].save();

  console.log("✅ Seed completed successfully!");
  console.log("\n--- Demo Credentials ---");
  console.log("Admin:     admin@jobportal.com / admin123");
  console.log("Recruiter: recruiter@techcorp.com / recruiter123");
  console.log("Recruiter: recruiter@innovate.com / recruiter123");
  console.log("Job Seeker: user@example.com / user1234");
  console.log("------------------------\n");

  await mongoose.connection.close();
  process.exit(0);
};

seed().catch((err) => {
  console.error("Seed error:", err);
  process.exit(1);
});
