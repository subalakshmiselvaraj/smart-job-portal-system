# 🚀 Smart Job Portal

A full-stack, premium job portal web application — built to look and feel like a real modern SaaS startup product. Dark glassmorphism UI, smooth animations, fully working authentication, job posting, search/filter, and application tracking.

![Tech](https://img.shields.io/badge/MERN-Stack-6366f1) ![License](https://img.shields.io/badge/License-MIT-8b5cf6)

---

## ✨ Features

- **Modern Dark UI** — Glassmorphism cards, gradient accents, smooth Framer Motion animations
- **JWT Authentication** — Secure login/register for Job Seekers and Recruiters with bcrypt password hashing
- **Role-Based Access Control** — Separate experiences for `user`, `recruiter`, and `admin`
- **Job Search & Filtering** — Live search by title/company/skills, filter by location & job type, pagination
- **Job Applications** — One-click apply with optional cover note, duplicate-application prevention
- **Application Tracking** — Job seekers track status (pending → shortlisted → accepted/rejected)
- **Recruiter Dashboard** — Post/edit/delete jobs, view & manage applicants, update application status
- **Fully Responsive** — Mobile, tablet, and desktop layouts
- **Toast Notifications** — Success/error feedback throughout
- **Seed Script** — Pre-populated demo data so the app looks great immediately

---

## 🛠️ Tech Stack

| Layer      | Technology                                                   |
|------------|----------------------------------------------------------------|
| Frontend   | React 19, Vite, React Router, Framer Motion, Axios, react-hot-toast, lucide-react |
| Backend    | Node.js, Express 4                                              |
| Database   | MongoDB + Mongoose                                              |
| Auth       | JWT + bcryptjs                                                  |

---

## 📁 Folder Structure

```
smart-job-portal/
├── backend/
│   ├── config/db.js              # MongoDB connection
│   ├── controllers/              # Route handler logic
│   │   ├── authController.js
│   │   ├── jobController.js
│   │   └── applicationController.js
│   ├── middleware/
│   │   ├── auth.js               # JWT protect + role authorize
│   │   └── errorHandler.js
│   ├── models/                   # Mongoose schemas
│   │   ├── User.js
│   │   ├── Job.js
│   │   └── Application.js
│   ├── routes/                   # Express routers
│   │   ├── authRoutes.js
│   │   ├── jobRoutes.js
│   │   └── applicationRoutes.js
│   ├── seed.js                   # Demo data seeder
│   ├── server.js                 # App entry point
│   ├── .env.example
│   └── package.json
│
└── frontend/
    ├── src/
    │   ├── api/                  # Axios instance + API call modules
    │   ├── components/           # Navbar, Footer, JobCard, ProtectedRoute, dashboard/
    │   ├── context/AuthContext.jsx
    │   ├── pages/                # Landing, Login, Register, Jobs, JobDetails, Dashboards
    │   ├── styles/                # theme.css, components.css, layout.css
    │   ├── utils/helpers.js
    │   ├── App.jsx
    │   └── main.jsx
    ├── .env.example
    └── package.json
```

---

## ⚡ Quick Start

### Prerequisites
- Node.js 18+
- MongoDB running locally (`mongodb://127.0.0.1:27017`) **or** a MongoDB Atlas connection string

### 1. Clone & install

```bash
# Backend
cd backend
npm install
cp .env.example .env
# edit .env if your Mongo URI / JWT secret differ

# Frontend
cd ../frontend
npm install
cp .env.example .env
```

### 2. Seed demo data (recommended)

```bash
cd backend
npm run seed
```

This creates demo accounts:

| Role       | Email                      | Password       |
|------------|------------------------------|-----------------|
| Admin      | admin@jobportal.com          | admin123        |
| Recruiter  | recruiter@techcorp.com       | recruiter123    |
| Recruiter  | recruiter@innovate.com       | recruiter123    |
| Job Seeker | user@example.com             | user1234        |

### 3. Run the app

```bash
# Terminal 1 — backend (http://localhost:5000)
cd backend
npm run dev

# Terminal 2 — frontend (http://localhost:5173)
cd frontend
npm run dev
```

Visit **http://localhost:5173** 🎉

---

## 🔌 API Reference

Base URL: `http://localhost:5000/api`

### Auth
| Method | Endpoint         | Access  | Description          |
|--------|------------------|---------|------------------------|
| POST   | `/auth/register` | Public  | Register user/recruiter |
| POST   | `/auth/login`    | Public  | Login & receive JWT    |
| GET    | `/auth/me`       | Private | Get current user       |

### Jobs
| Method | Endpoint                     | Access            | Description                  |
|--------|-------------------------------|--------------------|-------------------------------|
| GET    | `/jobs`                       | Public             | List jobs (search/filter/paginate) |
| GET    | `/jobs/:id`                   | Public             | Get single job                |
| POST   | `/jobs`                       | Recruiter/Admin    | Create a job                  |
| PUT    | `/jobs/:id`                   | Owner/Admin        | Update a job                  |
| DELETE | `/jobs/:id`                   | Owner/Admin        | Delete a job                  |
| GET    | `/jobs/recruiter/my-jobs`     | Recruiter/Admin    | List jobs posted by current recruiter |

### Applications
| Method | Endpoint                          | Access             | Description                |
|--------|-------------------------------------|---------------------|------------------------------|
| POST   | `/apply`                            | User                | Apply to a job              |
| GET    | `/applications/user`                | User                | Get my applications         |
| GET    | `/applications/job/:id`             | Owner Recruiter/Admin | Get applicants for a job  |
| PUT    | `/applications/:id/status`          | Owner Recruiter/Admin | Update application status |

`GET /jobs` query params: `search`, `location`, `skills`, `jobType`, `page`, `limit`

---

## 🗄️ Database Models

**User**: `name`, `email` (unique), `password` (hashed), `role` (user/recruiter/admin), `headline`, `location`, `skills[]`, `company`

**Job**: `title`, `company`, `description`, `skills[]`, `location`, `jobType`, `experience`, `salary {min,max}`, `postedBy` (ref User), `applicantsCount`

**Application**: `userId` (ref User), `jobId` (ref Job), `status` (pending/shortlisted/accepted/rejected), `coverNote` — unique compound index on `(userId, jobId)` to block duplicate applications.

---

## 🔒 Security Notes

- Passwords hashed with bcrypt (10 salt rounds) before storage
- JWT tokens expire after 7 days by default (configurable via `JWT_EXPIRES_IN`)
- Role-based middleware (`protect`, `authorize`) guards every sensitive route
- Recruiters can only edit/delete their **own** job postings (or admin override)
- Centralized error handler normalizes Mongoose/validation errors into clean JSON responses

---

## 🚀 Deployment Notes

- **Backend**: Deploy to Render / Railway / Fly.io. Set `MONGO_URI` to a MongoDB Atlas cluster, set `JWT_SECRET` to a long random string, set `CLIENT_URL` to your deployed frontend origin (for CORS).
- **Frontend**: Deploy to Vercel / Netlify. Set `VITE_API_URL` to your deployed backend's `/api` URL.
- Remember to run `npm run seed` against your production database once if you want demo data live (or remove it for a real launch).

---

## 📄 License

MIT — free to use for learning, portfolio, and interview purposes.
