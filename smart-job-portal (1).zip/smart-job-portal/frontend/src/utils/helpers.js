export const getErrorMessage = (err, fallback = "Something went wrong. Please try again.") => {
  if (err?.response?.data?.message) return err.response.data.message;
  if (err?.message) return err.message;
  return fallback;
};

export const formatSalary = (salary) => {
  if (!salary || (!salary.min && !salary.max)) return "Not disclosed";
  const fmt = (n) => {
    if (n >= 100000) return `₹${(n / 100000).toFixed(1)}L`;
    if (n >= 1000) return `₹${(n / 1000).toFixed(0)}K`;
    return `₹${n}`;
  };
  if (salary.min && salary.max) return `${fmt(salary.min)} - ${fmt(salary.max)}`;
  return fmt(salary.min || salary.max);
};

export const timeAgo = (dateStr) => {
  const date = new Date(dateStr);
  const seconds = Math.floor((new Date() - date) / 1000);

  const intervals = [
    { label: "year", secs: 31536000 },
    { label: "month", secs: 2592000 },
    { label: "day", secs: 86400 },
    { label: "hour", secs: 3600 },
    { label: "minute", secs: 60 },
  ];

  for (const interval of intervals) {
    const count = Math.floor(seconds / interval.secs);
    if (count >= 1) return `${count} ${interval.label}${count > 1 ? "s" : ""} ago`;
  }
  return "Just now";
};

export const getInitials = (name = "") => {
  return name
    .split(" ")
    .map((w) => w[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
};

export const statusBadgeClass = (status) => {
  switch (status) {
    case "accepted":
      return "badge-emerald";
    case "rejected":
      return "badge-red";
    case "shortlisted":
      return "badge-cyan";
    default:
      return "badge-amber";
  }
};
