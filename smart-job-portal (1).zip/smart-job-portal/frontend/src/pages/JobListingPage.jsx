import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Search, MapPin, X, Briefcase, ChevronLeft, ChevronRight } from "lucide-react";
import { jobsAPI } from "../api/jobs";
import JobCard from "../components/JobCard";
import { getErrorMessage } from "../utils/helpers";

const JOB_TYPES = ["Full-time", "Part-time", "Internship", "Contract", "Remote"];

const JobListingPage = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [location, setLocation] = useState("");
  const [jobType, setJobType] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const params = { page, limit: 9 };
      if (search.trim()) params.search = search.trim();
      if (location.trim()) params.location = location.trim();
      if (jobType) params.jobType = jobType;

      const res = await jobsAPI.getAll(params);
      setJobs(res.data.jobs);
      setTotalPages(res.data.totalPages || 1);
      setTotal(res.data.total || 0);
    } catch (err) {
      setError(getErrorMessage(err, "Failed to load jobs"));
    } finally {
      setLoading(false);
    }
  }, [page, search, location, jobType]);

  // Debounce search/location, instant on jobType/page
  useEffect(() => {
    const timer = setTimeout(() => {
      setPage(1);
      fetchJobs();
    }, 400);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search, location, jobType]);

  useEffect(() => {
    fetchJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  const clearFilters = () => {
    setSearch("");
    setLocation("");
    setJobType("");
    setPage(1);
  };

  const hasActiveFilters = search || location || jobType;

  return (
    <div className="container" style={{ padding: "44px 24px 80px" }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: "clamp(1.6rem, 3.5vw, 2.2rem)", marginBottom: 10 }}>
          Explore <span className="gradient-text">{total || ""} Jobs</span>
        </h1>
        <p style={{ color: "var(--text-secondary)" }}>Discover your next opportunity from top companies.</p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="card"
        style={{ padding: 18, marginBottom: 32 }}
      >
        <div className="filters-bar">
          <div className="input-with-icon">
            <Search size={17} />
            <input
              type="text"
              className="form-input"
              placeholder="Job title, company, or skill..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="input-with-icon">
            <MapPin size={17} />
            <input
              type="text"
              className="form-input"
              placeholder="Location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
          <select className="form-select" value={jobType} onChange={(e) => setJobType(e.target.value)}>
            <option value="">All Job Types</option>
            {JOB_TYPES.map((t) => (
              <option key={t} value={t}>{t}</option>
            ))}
          </select>
          {hasActiveFilters && (
            <button className="btn btn-ghost btn-sm" onClick={clearFilters}>
              <X size={15} /> Clear
            </button>
          )}
        </div>
      </motion.div>

      {loading ? (
        <div className="grid-jobs">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="card" style={{ padding: 24, height: 260 }}>
              <div className="skeleton" style={{ height: 46, width: 46, borderRadius: 12, marginBottom: 16 }} />
              <div className="skeleton" style={{ height: 16, width: "70%", marginBottom: 10 }} />
              <div className="skeleton" style={{ height: 12, width: "40%", marginBottom: 24 }} />
              <div className="skeleton" style={{ height: 12, width: "100%", marginBottom: 8 }} />
              <div className="skeleton" style={{ height: 12, width: "90%" }} />
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="empty-state">
          <Briefcase size={48} strokeWidth={1.5} />
          <h3>Couldn't load jobs</h3>
          <p>{error}</p>
        </div>
      ) : jobs.length === 0 ? (
        <div className="empty-state">
          <Search size={48} strokeWidth={1.5} />
          <h3>No jobs found</h3>
          <p>Try adjusting your filters or search terms to discover more opportunities.</p>
        </div>
      ) : (
        <>
          <div className="grid-jobs">
            {jobs.map((job, i) => (
              <JobCard job={job} key={job._id} index={i} />
            ))}
          </div>

          {totalPages > 1 && (
            <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 10, marginTop: 48 }}>
              <button
                className="btn btn-secondary btn-icon"
                disabled={page <= 1}
                onClick={() => { setPage((p) => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              >
                <ChevronLeft size={18} />
              </button>
              <span style={{ fontSize: "0.9rem", color: "var(--text-secondary)", padding: "0 8px" }}>
                Page {page} of {totalPages}
              </span>
              <button
                className="btn btn-secondary btn-icon"
                disabled={page >= totalPages}
                onClick={() => { setPage((p) => Math.min(totalPages, p + 1)); window.scrollTo({ top: 0, behavior: "smooth" }); }}
              >
                <ChevronRight size={18} />
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default JobListingPage;
