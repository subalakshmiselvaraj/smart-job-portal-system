import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Home, Search } from "lucide-react";

const NotFoundPage = () => {
  return (
    <div className="container" style={{ minHeight: "65vh", display: "flex", alignItems: "center", justifyContent: "center", padding: "60px 24px" }}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        style={{ textAlign: "center" }}
      >
        <div
          style={{
            fontSize: "7rem",
            fontWeight: 800,
            fontFamily: "var(--font-display)",
            lineHeight: 1,
            marginBottom: 8,
          }}
          className="gradient-text"
        >
          404
        </div>
        <h1 style={{ fontSize: "1.5rem", marginBottom: 12 }}>Page not found</h1>
        <p style={{ color: "var(--text-secondary)", maxWidth: 380, margin: "0 auto 32px" }}>
          The page you're looking for doesn't exist or may have been moved.
        </p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <Link to="/" className="btn btn-primary">
            <Home size={16} /> Back Home
          </Link>
          <Link to="/jobs" className="btn btn-secondary">
            <Search size={16} /> Browse Jobs
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default NotFoundPage;
