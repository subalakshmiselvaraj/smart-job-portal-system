import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Briefcase,
  Search,
  Sparkles,
  ArrowRight,
  Building2,
  Users,
  TrendingUp,
  ShieldCheck,
  Zap,
  Target,
  Star,
  CheckCircle2,
} from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.1, ease: [0.16, 1, 0.3, 1] },
  }),
};

const stats = [
  { value: "25K+", label: "Active Jobs" },
  { value: "8K+", label: "Companies" },
  { value: "120K+", label: "Job Seekers" },
  { value: "94%", label: "Success Rate" },
];

const features = [
  {
    icon: Search,
    gradient: "var(--gradient-primary)",
    title: "Smart Job Matching",
    desc: "Our intelligent search understands skills and intent, surfacing roles that actually fit your profile.",
  },
  {
    icon: Zap,
    gradient: "var(--gradient-warm)",
    title: "Apply in One Click",
    desc: "Skip repetitive forms. Apply to multiple roles instantly with your saved profile and resume.",
  },
  {
    icon: ShieldCheck,
    gradient: "var(--gradient-success)",
    title: "Verified Companies",
    desc: "Every recruiter and company on our platform is verified, so you only see legitimate opportunities.",
  },
  {
    icon: TrendingUp,
    gradient: "var(--gradient-cool)",
    title: "Track Applications",
    desc: "A real-time dashboard shows exactly where you stand — pending, shortlisted, accepted, or rejected.",
  },
  {
    icon: Target,
    gradient: "var(--gradient-primary)",
    title: "Precision Filters",
    desc: "Filter by skills, location, job type and experience to find exactly what you're looking for.",
  },
  {
    icon: Building2,
    gradient: "var(--gradient-warm)",
    title: "Recruiter Tools",
    desc: "Post jobs, manage applicants, and track your hiring pipeline — all from one beautiful dashboard.",
  },
];

const steps = [
  { number: "01", title: "Create your profile", desc: "Sign up in seconds and tell us about your skills and goals." },
  { number: "02", title: "Discover opportunities", desc: "Browse curated jobs that match your experience and interests." },
  { number: "03", title: "Apply & get hired", desc: "Apply with one click and track your progress in real time." },
];

const testimonials = [
  {
    name: "Ananya Iyer",
    role: "Frontend Engineer @ TechCorp",
    quote: "I found and landed my current role in under two weeks. The whole experience felt premium and effortless.",
  },
  {
    name: "Rahul Verma",
    role: "Hiring Manager @ Innovate Labs",
    quote: "Posting jobs and reviewing applicants has never been this smooth. The dashboard saves us hours every week.",
  },
  {
    name: "Sneha Patil",
    role: "Product Designer",
    quote: "Clean, fast, and genuinely helpful filters. It's the first job portal that didn't feel like a chore to use.",
  },
];

const LandingPage = () => {
  return (
    <div>
      {/* HERO */}
      <section className="hero-section">
        <div
          className="hero-blob"
          style={{ width: 420, height: 420, background: "#6366f1", top: -120, left: "8%" }}
        />
        <div
          className="hero-blob"
          style={{ width: 380, height: 380, background: "#ec4899", top: -60, right: "5%", animationDelay: "2s" }}
        />
        <div className="container">
          <motion.div className="hero-content" initial="hidden" animate="show">
            <motion.div variants={fadeUp} custom={0} className="section-eyebrow glass" style={{ padding: "8px 18px", borderRadius: "var(--radius-full)", margin: "0 auto 24px" }}>
              <Sparkles size={14} /> AI-Powered Job Matching is Here
            </motion.div>

            <motion.h1
              variants={fadeUp}
              custom={1}
              style={{ fontSize: "clamp(2.4rem, 6vw, 4.2rem)", marginBottom: 22, lineHeight: 1.08 }}
            >
              Find your <span className="gradient-text">dream job</span>
              <br /> faster than ever
            </motion.h1>

            <motion.p
              variants={fadeUp}
              custom={2}
              style={{ fontSize: "1.15rem", color: "var(--text-secondary)", maxWidth: 580, margin: "0 auto 40px", lineHeight: 1.7 }}
            >
              Smart Job Portal connects ambitious talent with the world's most exciting companies.
              Beautiful, fast, and built for how careers actually grow.
            </motion.p>

            <motion.div variants={fadeUp} custom={3} style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
              <Link to="/register" className="btn btn-primary btn-lg">
                Get Started Free <ArrowRight size={18} />
              </Link>
              <Link to="/jobs" className="btn btn-secondary btn-lg">
                Explore Jobs
              </Link>
            </motion.div>

            <motion.div variants={fadeUp} custom={4} className="hero-stats">
              {stats.map((s) => (
                <div key={s.label} style={{ textAlign: "center" }}>
                  <div style={{ fontSize: "2rem", fontWeight: 800, fontFamily: "var(--font-display)" }} className="gradient-text">
                    {s.value}
                  </div>
                  <div style={{ fontSize: "0.85rem", color: "var(--text-tertiary)", marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* COMPANY STRIP */}
      <section style={{ padding: "20px 0 70px" }}>
        <div className="container">
          <p style={{ textAlign: "center", color: "var(--text-tertiary)", fontSize: "0.82rem", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 28 }}>
            Trusted by fast-growing teams
          </p>
          <div className="company-strip">
            {["TechCorp", "Innovate Labs", "Nexora", "Bluepeak", "Cloudstack", "Veridian"].map((c) => (
              <span key={c} style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.1rem", color: "var(--text-secondary)" }}>
                {c}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section style={{ padding: "60px 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", maxWidth: 640, margin: "0 auto 56px" }}>
            <div className="section-eyebrow" style={{ justifyContent: "center" }}>
              <Star size={14} /> Why Choose Us
            </div>
            <h2 className="section-title">Everything you need to land the role</h2>
            <p className="section-subtitle" style={{ margin: "0 auto" }}>
              From intelligent search to real-time tracking, we built every detail to make your job
              search (or your hiring process) feel effortless.
            </p>
          </div>

          <div className="feature-grid">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.08 }}
                className="card"
                style={{ padding: 28 }}
              >
                <div
                  style={{
                    width: 50,
                    height: 50,
                    borderRadius: 14,
                    background: f.gradient,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginBottom: 20,
                  }}
                >
                  <f.icon size={22} color="white" />
                </div>
                <h3 style={{ fontSize: "1.08rem", marginBottom: 10 }}>{f.title}</h3>
                <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", lineHeight: 1.65 }}>{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section style={{ padding: "70px 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", maxWidth: 600, margin: "0 auto 60px" }}>
            <div className="section-eyebrow" style={{ justifyContent: "center" }}>
              <Zap size={14} /> Simple Process
            </div>
            <h2 className="section-title">How it works</h2>
            <p className="section-subtitle" style={{ margin: "0 auto" }}>Three simple steps between you and your next opportunity.</p>
          </div>

          <div className="steps-grid">
            {steps.map((s, i) => (
              <motion.div
                key={s.number}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                style={{ textAlign: "center", padding: "0 16px" }}
              >
                <div
                  style={{
                    width: 64,
                    height: 64,
                    borderRadius: "50%",
                    background: "var(--gradient-primary)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    margin: "0 auto 22px",
                    fontFamily: "var(--font-display)",
                    fontWeight: 800,
                    fontSize: "1.2rem",
                    color: "white",
                    boxShadow: "var(--shadow-glow-indigo)",
                  }}
                >
                  {s.number}
                </div>
                <h3 style={{ fontSize: "1.1rem", marginBottom: 10 }}>{s.title}</h3>
                <p style={{ fontSize: "0.9rem", color: "var(--text-secondary)", lineHeight: 1.6 }}>{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section style={{ padding: "70px 0" }}>
        <div className="container">
          <div style={{ textAlign: "center", maxWidth: 600, margin: "0 auto 56px" }}>
            <div className="section-eyebrow" style={{ justifyContent: "center" }}>
              <Users size={14} /> Loved By Thousands
            </div>
            <h2 className="section-title">What people are saying</h2>
          </div>

          <div className="feature-grid">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.name}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.5, delay: i * 0.1 }}
                className="card"
                style={{ padding: 28 }}
              >
                <div style={{ display: "flex", gap: 3, marginBottom: 16 }}>
                  {[...Array(5)].map((_, idx) => (
                    <Star key={idx} size={14} fill="#f59e0b" color="#f59e0b" />
                  ))}
                </div>
                <p style={{ fontSize: "0.92rem", color: "var(--text-secondary)", lineHeight: 1.7, marginBottom: 22, fontStyle: "italic" }}>
                  "{t.quote}"
                </p>
                <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                  <div
                    className="avatar"
                    style={{ width: 40, height: 40, background: "var(--gradient-cool)", fontSize: "0.8rem" }}
                  >
                    {t.name.split(" ").map((w) => w[0]).join("")}
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: "0.88rem" }}>{t.name}</div>
                    <div style={{ fontSize: "0.78rem", color: "var(--text-tertiary)" }}>{t.role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "40px 0 90px" }}>
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            style={{
              borderRadius: "var(--radius-lg)",
              padding: "64px 40px",
              textAlign: "center",
              position: "relative",
              overflow: "hidden",
              background: "var(--gradient-primary)",
            }}
          >
            <div
              style={{
                position: "absolute",
                inset: 0,
                background: "radial-gradient(circle at 30% 20%, rgba(255,255,255,0.18), transparent 50%)",
              }}
            />
            <div style={{ position: "relative", zIndex: 1 }}>
              <Briefcase size={36} color="white" style={{ marginBottom: 18, opacity: 0.9 }} />
              <h2 style={{ fontSize: "clamp(1.6rem, 4vw, 2.3rem)", color: "white", marginBottom: 16 }}>
                Ready to take the next step in your career?
              </h2>
              <p style={{ color: "rgba(255,255,255,0.85)", maxWidth: 480, margin: "0 auto 32px", fontSize: "1rem" }}>
                Join thousands of professionals who found their dream job through Smart Job Portal.
              </p>
              <div style={{ display: "flex", gap: 14, justifyContent: "center", flexWrap: "wrap" }}>
                <Link
                  to="/register"
                  className="btn btn-lg"
                  style={{ background: "white", color: "#6366f1", fontWeight: 700 }}
                >
                  Create Free Account <ArrowRight size={18} />
                </Link>
              </div>
              <div style={{ display: "flex", gap: 24, justifyContent: "center", marginTop: 28, flexWrap: "wrap" }}>
                {["No credit card required", "Free forever plan", "Cancel anytime"].map((t) => (
                  <span key={t} style={{ display: "flex", alignItems: "center", gap: 6, color: "rgba(255,255,255,0.85)", fontSize: "0.85rem" }}>
                    <CheckCircle2 size={14} /> {t}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default LandingPage;
