import { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import {
  MapPin,
  IndianRupee,
  Clock,
  Users,
  CheckCircle2,
  ArrowLeft,
  Building2,
  GraduationCap,
  Send,
} from "lucide-react";
import { jobsAPI } from "../api/jobs";
import { applicationsAPI } from "../api/applications";
import { useAuth } from "../context/AuthContext";
import { formatSalary, timeAgo, getInitials, getErrorMessage } from "../utils/helpers";
import Loader from "../components/Loader";

const JobDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [hasApplied, setHasApplied] = useState(false);
  const [coverNote, setCoverNote] = useState("");
  const [showApplyForm, setShowApplyForm] = useState(false);

  useEffect(() => {
    const fetchJob = async () => {
      setLoading(true);
      try {
        const res = await jobsAPI.getById(id);
        setJob(res.data.job);
      } catch (err) {
        toast.error(getErrorMessage(err, "Job not found"));
        navigate("/jobs");
      } finally {
        setLoading(false);
      }
    };
    fetchJob();
  }, [id, navigate]);

  useEffect(() => {
    const checkApplied = async () => {
      if (user?.role !== "user") return;
      try {
        const res = await applicationsAPI.getUserApplications();
        const applied = res.data.applications.some((app) => app.jobId?._id === id);
        setHasApplied(applied);
      } catch {
        // silent
      }
    };
    checkApplied();
  }, [user, id]);

  const handleApply = async () => {
    if (!user) {
      toast.error("Please login to apply for this job");
      navigate("/login", { state: { from: { pathname: `/jobs/${id}` } } });
      return;
    }
    if (user.role !== "user") {
      toast.error("Only job seekers can apply to jobs");
      return;
    }

    setApplying(true);
    try {
      await applicationsAPI.apply({ jobId: id, coverNote });
      toast.success("Application submitted successfully! 🎉");
      setHasApplied(true);
      setShowApplyForm(false);
      setJob((prev) => ({ ...prev, applicantsCount: (prev.applicantsCount || 0) + 1 }));
    } catch (err) {
      toast.error(getErrorMessage(err, "Failed to apply"));
    } finally {
      setApplying(false);
    }
  };

  if (loading) return <Loader fullPage />;
  if (!job) return null;

  return (
    <div className="container" style={{ padding: "36px 24px 80px" }}>
      <button onClick={() => navigate(-1)} className="btn btn-ghost btn-sm" style={{ marginBottom: 24 }}>
        <ArrowLeft size={16} /> Back
      </button>

      <div className="job-details-layout">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.45 }}>
          <div className="card" style={{ padding: 32, marginBottom: 24 }}>
            <div style={{ display: "flex", gap: 18, alignItems: "flex-start", flexWrap: "wrap" }}>
              <div
                className="avatar"
                style={{ width: 64, height: 64, fontSize: "1.3rem", borderRadius: 16, background: "var(--gradient-cool)" }}
              >
                {getInitials(job.company)}
              </div>
              <div style={{ flex: 1, minWidth: 200 }}>
                <h1 style={{ fontSize: "1.7rem", marginBottom: 8 }}>{job.title}</h1>
                <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--text-secondary)", fontSize: "1rem", fontWeight: 500 }}>
                  <Building2 size={16} /> {job.company}
                </div>
              </div>
              <span className="badge badge-indigo" style={{ fontSize: "0.85rem", padding: "8px 18px" }}>
                {job.jobType}
              </span>
            </div>

            <div style={{ display: "flex", flexWrap: "wrap", gap: 20, marginTop: 28, paddingTop: 24, borderTop: "1px solid var(--border-subtle)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                <MapPin size={16} color="var(--accent-violet)" /> {job.location}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                <IndianRupee size={16} color="var(--accent-emerald)" /> {formatSalary(job.salary)}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                <GraduationCap size={16} color="var(--accent-cyan)" /> {job.experience}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                <Clock size={16} color="var(--accent-amber)" /> Posted {timeAgo(job.createdAt)}
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
                <Users size={16} color="var(--accent-pink)" /> {job.applicantsCount || 0} applicants
              </div>
            </div>
          </div>

          <div className="card" style={{ padding: 32, marginBottom: 24 }}>
            <h2 style={{ fontSize: "1.2rem", marginBottom: 16 }}>Job Description</h2>
            <p style={{ color: "var(--text-secondary)", lineHeight: 1.8, whiteSpace: "pre-line" }}>{job.description}</p>
          </div>

          <div className="card" style={{ padding: 32 }}>
            <h2 style={{ fontSize: "1.2rem", marginBottom: 18 }}>Required Skills</h2>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
              {(job.skills || []).map((skill) => (
                <span key={skill} className="badge badge-violet" style={{ fontSize: "0.85rem", padding: "8px 16px" }}>
                  <CheckCircle2 size={13} /> {skill}
                </span>
              ))}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1 }}
          className="sticky-card"
        >
          <div className="card" style={{ padding: 28 }}>
            <h3 style={{ fontSize: "1.05rem", marginBottom: 18 }}>Apply for this position</h3>

            {hasApplied ? (
              <div style={{ textAlign: "center", padding: "20px 0" }}>
                <CheckCircle2 size={40} color="var(--accent-emerald)" style={{ marginBottom: 12 }} />
                <p style={{ fontWeight: 600, marginBottom: 4 }}>Application Submitted</p>
                <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)" }}>
                  Check your dashboard to track the status.
                </p>
                <Link to="/dashboard" className="btn btn-secondary btn-block" style={{ marginTop: 16 }}>
                  View My Applications
                </Link>
              </div>
            ) : showApplyForm ? (
              <>
                <div className="form-group">
                  <label className="form-label">Cover Note (optional)</label>
                  <textarea
                    className="form-textarea"
                    placeholder="Tell the recruiter why you're a great fit..."
                    value={coverNote}
                    onChange={(e) => setCoverNote(e.target.value)}
                    rows={5}
                  />
                </div>
                <button onClick={handleApply} className="btn btn-primary btn-block" disabled={applying}>
                  {applying ? <div className="spinner" /> : <>Submit Application <Send size={16} /></>}
                </button>
                <button onClick={() => setShowApplyForm(false)} className="btn btn-ghost btn-block" style={{ marginTop: 8 }}>
                  Cancel
                </button>
              </>
            ) : (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => (user ? setShowApplyForm(true) : handleApply())}
                className="btn btn-primary btn-block btn-lg"
              >
                Apply Now <Send size={16} />
              </motion.button>
            )}

            <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--border-subtle)" }}>
              <p style={{ fontSize: "0.8rem", color: "var(--text-tertiary)", marginBottom: 12 }}>About the company</p>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <div className="avatar" style={{ width: 38, height: 38, fontSize: "0.78rem", background: "var(--gradient-warm)" }}>
                  {getInitials(job.company)}
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: "0.88rem" }}>{job.company}</div>
                  <div style={{ fontSize: "0.78rem", color: "var(--text-tertiary)" }}>Verified Employer</div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default JobDetailsPage;
