import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import { Mail, Lock, User, Briefcase, ArrowRight, Eye, EyeOff, Building2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getErrorMessage } from "../utils/helpers";

const RegisterPage = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState("user");
  const [form, setForm] = useState({ name: "", email: "", password: "", confirmPassword: "", company: "" });
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Full name is required";
    else if (form.name.trim().length < 2) errs.name = "Name is too short";

    if (!form.email.trim()) errs.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = "Enter a valid email";

    if (!form.password) errs.password = "Password is required";
    else if (form.password.length < 6) errs.password = "Must be at least 6 characters";

    if (form.confirmPassword !== form.password) errs.confirmPassword = "Passwords do not match";

    if (role === "recruiter" && !form.company.trim()) errs.company = "Company name is required";

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const user = await register({
        name: form.name,
        email: form.email,
        password: form.password,
        role,
        company: form.company,
      });
      toast.success(`Welcome to Smart Job Portal, ${user.name.split(" ")[0]}!`);
      navigate(role === "recruiter" ? "/recruiter/dashboard" : "/dashboard");
    } catch (err) {
      toast.error(getErrorMessage(err, "Could not create account"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="hero-blob" style={{ width: 360, height: 360, background: "#8b5cf6", top: "5%", right: "-5%" }} />
      <div className="hero-blob" style={{ width: 320, height: 320, background: "#06b6d4", bottom: "0%", left: "-5%", animationDelay: "1.5s" }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="auth-card glass"
        style={{ maxWidth: 480 }}
      >
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <Link to="/" style={{ display: "inline-flex", marginBottom: 18 }}>
            <div
              style={{
                width: 50,
                height: 50,
                borderRadius: 14,
                background: "var(--gradient-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "var(--shadow-glow-indigo)",
              }}
            >
              <Briefcase size={24} color="white" />
            </div>
          </Link>
          <h1 style={{ fontSize: "1.6rem", marginBottom: 8 }}>Create your account</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.92rem" }}>Start your journey with Smart Job Portal</p>
        </div>

        <div className="tabs" style={{ width: "100%", marginBottom: 24 }}>
          <button type="button" className={`tab-btn ${role === "user" ? "active" : ""}`} style={{ flex: 1 }} onClick={() => setRole("user")}>
            I'm Job Seeking
          </button>
          <button type="button" className={`tab-btn ${role === "recruiter" ? "active" : ""}`} style={{ flex: 1 }} onClick={() => setRole("recruiter")}>
            I'm Hiring
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <div className="input-with-icon">
              <User size={17} />
              <input
                type="text"
                className={`form-input ${errors.name ? "error" : ""}`}
                placeholder="Your full name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
            </div>
            {errors.name && <span className="form-error">{errors.name}</span>}
          </div>

          {role === "recruiter" && (
            <div className="form-group">
              <label className="form-label">Company Name</label>
              <div className="input-with-icon">
                <Building2 size={17} />
                <input
                  type="text"
                  className={`form-input ${errors.company ? "error" : ""}`}
                  placeholder="Your company name"
                  value={form.company}
                  onChange={(e) => setForm({ ...form, company: e.target.value })}
                />
              </div>
              {errors.company && <span className="form-error">{errors.company}</span>}
            </div>
          )}

          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div className="input-with-icon">
              <Mail size={17} />
              <input
                type="email"
                className={`form-input ${errors.email ? "error" : ""}`}
                placeholder="you@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            {errors.email && <span className="form-error">{errors.email}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-with-icon" style={{ position: "relative" }}>
              <Lock size={17} />
              <input
                type={showPassword ? "text" : "password"}
                className={`form-input ${errors.password ? "error" : ""}`}
                placeholder="At least 6 characters"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                style={{ paddingRight: 46 }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", color: "var(--text-tertiary)" }}
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
            {errors.password && <span className="form-error">{errors.password}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Confirm Password</label>
            <div className="input-with-icon">
              <Lock size={17} />
              <input
                type="password"
                className={`form-input ${errors.confirmPassword ? "error" : ""}`}
                placeholder="Re-enter password"
                value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
              />
            </div>
            {errors.confirmPassword && <span className="form-error">{errors.confirmPassword}</span>}
          </div>

          <button type="submit" className="btn btn-primary btn-block btn-lg" disabled={loading} style={{ marginTop: 8 }}>
            {loading ? <div className="spinner" /> : <>Create Account <ArrowRight size={18} /></>}
          </button>
        </form>

        <p style={{ textAlign: "center", marginTop: 24, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
          Already have an account?{" "}
          <Link to="/login" style={{ color: "var(--accent-violet)", fontWeight: 600 }}>
            Sign in
          </Link>
        </p>
      </motion.div>
    </div>
  );
};

export default RegisterPage;
