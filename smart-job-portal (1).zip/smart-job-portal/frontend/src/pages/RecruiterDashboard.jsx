import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import toast from "react-hot-toast";
import {
  Plus,
  Briefcase,
  Users,
  Eye,
  Pencil,
  Trash2,
  MapPin,
  IndianRupee,
  TrendingUp,
  Building2,
} from "lucide-react";
import { jobsAPI } from "../api/jobs";
import { useAuth } from "../context/AuthContext";
import { formatSalary, timeAgo, getErrorMessage, getInitials } from "../utils/helpers";
import Loader from "../components/Loader";
import JobFormPanel from "../components/dashboard/JobFormPanel";
import ApplicantsPanel from "../components/dashboard/ApplicantsPanel";

const RecruiterDashboard = () => {
  const { user } = useAuth();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editJob, setEditJob] = useState(null);
  const [applicantsJob, setApplicantsJob] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const res = await jobsAPI.getMyJobs();
      setJobs(res.data.jobs);
    } catch (err) {
      toast.error(getErrorMessage(err, "Failed to load your jobs"));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs();
  }, [fetchJobs]);

  const handleDelete = async (jobId) => {
    setDeletingId(jobId);
    try {
      await jobsAPI.delete(jobId);
      setJobs((prev) => prev.filter((j) => j._id !== jobId));
      toast.success("Job deleted successfully");
    } catch (err) {
      toast.error(getErrorMessage(err, "Failed to delete job"));
    } finally {
      setDeletingId(null);
      setConfirmDeleteId(null);
    }
  };

  const totalApplicants = jobs.reduce((sum, j) => sum + (j.applicantsCount || 0), 0);
  const activeJobs = jobs.filter((j) => j.isActive).length;

  if (loading) return <Loader fullPage />;

  return (
    <div className="container" style={{ padding: "40px 24px 80px" }}>
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32, flexWrap: "wrap", gap: 16 }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: "1.2rem", background: user?.avatarColor || "var(--accent-violet)" }}>
            {getInitials(user?.name || "R")}
          </div>
          <div>
            <h1 style={{ fontSize: "1.5rem" }}>Recruiter Dashboard</h1>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", display: "flex", alignItems: "center", gap: 6 }}>
              <Building2 size={14} /> {user?.company || "Your Company"}
            </p>
          </div>
        </div>
        <button onClick={() => { setEditJob(null); setShowForm(true); }} className="btn btn-primary">
          <Plus size={17} /> Post New Job
        </button>
      </motion.div>

      <div className="stat-grid" style={{ marginBottom: 36 }}>
        {[
          { label: "Jobs Posted", value: jobs.length, icon: Briefcase, color: "var(--gradient-primary)" },
          { label: "Active Jobs", value: activeJobs, icon: TrendingUp, color: "var(--gradient-success)" },
          { label: "Total Applicants", value: totalApplicants, icon: Users, color: "var(--gradient-cool)" },
          { label: "Avg. per Job", value: jobs.length ? Math.round(totalApplicants / jobs.length) : 0, icon: Eye, color: "var(--gradient-warm)" },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="card"
            style={{ padding: 22 }}
          >
            <div style={{ width: 40, height: 40, borderRadius: 11, background: s.color, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
              <s.icon size={18} color="white" />
            </div>
            <div style={{ fontSize: "1.6rem", fontWeight: 800, fontFamily: "var(--font-display)" }}>{s.value}</div>
            <div style={{ fontSize: "0.82rem", color: "var(--text-tertiary)" }}>{s.label}</div>
          </motion.div>
        ))}
      </div>

      <h2 style={{ fontSize: "1.15rem", marginBottom: 18 }}>Your Job Postings</h2>

      {jobs.length === 0 ? (
        <div className="empty-state card">
          <Briefcase size={48} strokeWidth={1.5} />
          <h3>No jobs posted yet</h3>
          <p>Create your first job posting to start receiving applications.</p>
          <button onClick={() => setShowForm(true)} className="btn btn-primary" style={{ marginTop: 20 }}>
            <Plus size={16} /> Post a Job
          </button>
        </div>
      ) : (
        <div className="card table-responsive" style={{ padding: 0 }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>Job</th>
                <th>Location</th>
                <th>Salary</th>
                <th>Applicants</th>
                <th>Posted</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {jobs.map((job) => (
                <tr key={job._id}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <div className="avatar" style={{ width: 36, height: 36, fontSize: "0.72rem", borderRadius: 10, background: "var(--gradient-cool)" }}>
                        {getInitials(job.company)}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600 }}>{job.title}</div>
                        <span className="badge badge-gray" style={{ marginTop: 4 }}>{job.jobType}</span>
                      </div>
                    </div>
                  </td>
                  <td style={{ color: "var(--text-secondary)" }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 5 }}><MapPin size={13} /> {job.location}</span>
                  </td>
                  <td style={{ color: "var(--text-secondary)" }}>
                    <span style={{ display: "flex", alignItems: "center", gap: 5 }}><IndianRupee size={13} /> {formatSalary(job.salary)}</span>
                  </td>
                  <td>
                    <button onClick={() => setApplicantsJob(job)} className="badge badge-violet" style={{ cursor: "pointer" }}>
                      <Users size={12} /> {job.applicantsCount || 0}
                    </button>
                  </td>
                  <td style={{ color: "var(--text-tertiary)", fontSize: "0.82rem" }}>{timeAgo(job.createdAt)}</td>
                  <td>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => setApplicantsJob(job)} className="btn btn-icon btn-secondary" title="View applicants">
                        <Eye size={15} />
                      </button>
                      <button onClick={() => { setEditJob(job); setShowForm(true); }} className="btn btn-icon btn-secondary" title="Edit job">
                        <Pencil size={15} />
                      </button>
                      {confirmDeleteId === job._id ? (
                        <button
                          onClick={() => handleDelete(job._id)}
                          className="btn btn-danger btn-sm"
                          disabled={deletingId === job._id}
                        >
                          {deletingId === job._id ? <div className="spinner" /> : "Confirm?"}
                        </button>
                      ) : (
                        <button onClick={() => setConfirmDeleteId(job._id)} className="btn btn-icon btn-danger" title="Delete job">
                          <Trash2 size={15} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <AnimatePresence>
        {showForm && (
          <JobFormPanel
            editJob={editJob}
            defaultCompany={user?.company}
            onClose={() => { setShowForm(false); setEditJob(null); }}
            onSuccess={() => { setShowForm(false); setEditJob(null); fetchJobs(); }}
          />
        )}
        {applicantsJob && <ApplicantsPanel job={applicantsJob} onClose={() => setApplicantsJob(null)} />}
      </AnimatePresence>
    </div>
  );
};

export default RecruiterDashboard;
