import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Briefcase,
  Clock,
  CheckCircle2,
  XCircle,
  Hourglass,
  MapPin,
  IndianRupee,
  ArrowRight,
} from "lucide-react";
import { applicationsAPI } from "../api/applications";
import { useAuth } from "../context/AuthContext";
import { formatSalary, timeAgo, statusBadgeClass, getErrorMessage, getInitials } from "../utils/helpers";
import Loader from "../components/Loader";
import toast from "react-hot-toast";

const statusIcon = {
  pending: Hourglass,
  shortlisted: Clock,
  accepted: CheckCircle2,
  rejected: XCircle,
};

const UserDashboard = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const res = await applicationsAPI.getUserApplications();
        setApplications(res.data.applications);
      } catch (err) {
        toast.error(getErrorMessage(err, "Failed to load applications"));
      } finally {
        setLoading(false);
      }
    };
    fetchApplications();
  }, []);

  const counts = {
    all: applications.length,
    pending: applications.filter((a) => a.status === "pending").length,
    shortlisted: applications.filter((a) => a.status === "shortlisted").length,
    accepted: applications.filter((a) => a.status === "accepted").length,
    rejected: applications.filter((a) => a.status === "rejected").length,
  };

  const filtered = filter === "all" ? applications : applications.filter((a) => a.status === filter);

  if (loading) return <Loader fullPage />;

  return (
    <div className="container" style={{ padding: "40px 24px 80px" }}>
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} style={{ marginBottom: 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 8 }}>
          <div className="avatar" style={{ width: 56, height: 56, fontSize: "1.2rem", background: user?.avatarColor || "var(--accent-violet)" }}>
            {getInitials(user?.name || "U")}
          </div>
          <div>
            <h1 style={{ fontSize: "1.5rem" }}>Welcome back, {user?.name?.split(" ")[0]}</h1>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>Track and manage your job applications</p>
          </div>
        </div>
      </motion.div>

      <div className="stat-grid" style={{ marginBottom: 32 }}>
        {[
          { label: "Total Applied", value: counts.all, icon: Briefcase, color: "var(--gradient-primary)" },
          { label: "Pending", value: counts.pending, icon: Hourglass, color: "var(--gradient-warm)" },
          { label: "Shortlisted", value: counts.shortlisted, icon: Clock, color: "var(--gradient-cool)" },
          { label: "Accepted", value: counts.accepted, icon: CheckCircle2, color: "var(--gradient-success)" },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.08 }}
            className="card"
            style={{ padding: 22 }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 11, background: s.color, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <s.icon size={18} color="white" />
              </div>
            </div>
            <div style={{ fontSize: "1.6rem", fontWeight: 800, fontFamily: "var(--font-display)" }}>{s.value}</div>
            <div style={{ fontSize: "0.82rem", color: "var(--text-tertiary)" }}>{s.label}</div>
          </motion.div>
        ))}
      </div>

      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
        <div className="tabs">
          {["all", "pending", "shortlisted", "accepted", "rejected"].map((f) => (
            <button key={f} className={`tab-btn ${filter === f ? "active" : ""}`} onClick={() => setFilter(f)}>
              {f.charAt(0).toUpperCase() + f.slice(1)} {f !== "all" && `(${counts[f]})`}
            </button>
          ))}
        </div>
        <Link to="/jobs" className="btn btn-primary btn-sm">
          Browse More Jobs <ArrowRight size={15} />
        </Link>
      </div>

      {filtered.length === 0 ? (
        <div className="empty-state card">
          <Briefcase size={48} strokeWidth={1.5} />
          <h3>No applications yet</h3>
          <p>Start applying to jobs and track your progress right here.</p>
          <Link to="/jobs" className="btn btn-primary" style={{ marginTop: 20 }}>
            Explore Jobs
          </Link>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          {filtered.map((app, i) => {
            const StatusIcon = statusIcon[app.status] || Hourglass;
            const job = app.jobId;
            if (!job) return null;
            return (
              <motion.div
                key={app._id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.35, delay: Math.min(i * 0.05, 0.3) }}
                className="card"
                style={{ padding: 24, display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap" }}
              >
                <div className="avatar" style={{ width: 50, height: 50, fontSize: "1rem", borderRadius: 13, background: "var(--gradient-cool)" }}>
                  {getInitials(job.company)}
                </div>
                <div style={{ flex: 1, minWidth: 200 }}>
                  <Link to={`/jobs/${job._id}`} style={{ fontWeight: 700, fontSize: "1.02rem" }}>
                    {job.title}
                  </Link>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 14, marginTop: 6, fontSize: "0.83rem", color: "var(--text-secondary)" }}>
                    <span>{job.company}</span>
                    <span style={{ display: "flex", alignItems: "center", gap: 4 }}><MapPin size={12} /> {job.location}</span>
                    <span style={{ display: "flex", alignItems: "center", gap: 4 }}><IndianRupee size={12} /> {formatSalary(job.salary)}</span>
                  </div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                  <span style={{ fontSize: "0.78rem", color: "var(--text-tertiary)" }}>Applied {timeAgo(app.createdAt)}</span>
                  <span className={`badge ${statusBadgeClass(app.status)}`}>
                    <StatusIcon size={12} /> {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default UserDashboard;
