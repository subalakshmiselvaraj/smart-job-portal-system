import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import { Mail, Lock, Eye, EyeOff, Briefcase, ArrowRight } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getErrorMessage } from "../utils/helpers";

const LoginPage = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: "", password: "" });
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const errs = {};
    if (!form.email.trim()) errs.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = "Enter a valid email";
    if (!form.password) errs.password = "Password is required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const user = await login(form.email, form.password);
      toast.success(`Welcome back, ${user.name.split(" ")[0]}!`);
      const redirectTo = location.state?.from?.pathname;
      if (redirectTo) navigate(redirectTo);
      else if (user.role === "recruiter" || user.role === "admin") navigate("/recruiter/dashboard");
      else navigate("/dashboard");
    } catch (err) {
      toast.error(getErrorMessage(err, "Invalid email or password"));
    } finally {
      setLoading(false);
    }
  };

  const fillDemo = (role) => {
    if (role === "user") setForm({ email: "user@example.com", password: "user1234" });
    else setForm({ email: "recruiter@techcorp.com", password: "recruiter123" });
  };

  return (
    <div className="auth-page">
      <div className="hero-blob" style={{ width: 360, height: 360, background: "#6366f1", top: "10%", left: "-5%" }} />
      <div className="hero-blob" style={{ width: 320, height: 320, background: "#ec4899", bottom: "5%", right: "-5%", animationDelay: "1.5s" }} />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="auth-card glass"
      >
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <Link to="/" style={{ display: "inline-flex", marginBottom: 18 }}>
            <div
              style={{
                width: 50,
                height: 50,
                borderRadius: 14,
                background: "var(--gradient-primary)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: "var(--shadow-glow-indigo)",
              }}
            >
              <Briefcase size={24} color="white" />
            </div>
          </Link>
          <h1 style={{ fontSize: "1.6rem", marginBottom: 8 }}>Welcome back</h1>
          <p style={{ color: "var(--text-secondary)", fontSize: "0.92rem" }}>Sign in to continue your journey</p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div className="form-group">
            <label className="form-label">Email Address</label>
            <div className="input-with-icon">
              <Mail size={17} />
              <input
                type="email"
                className={`form-input ${errors.email ? "error" : ""}`}
                placeholder="you@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
            </div>
            {errors.email && <span className="form-error">{errors.email}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <div className="input-with-icon" style={{ position: "relative" }}>
              <Lock size={17} />
              <input
                type={showPassword ? "text" : "password"}
                className={`form-input ${errors.password ? "error" : ""}`}
                placeholder="Enter your password"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                style={{ paddingRight: 46 }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)", color: "var(--text-tertiary)" }}
              >
                {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
            {errors.password && <span className="form-error">{errors.password}</span>}
          </div>

          <button type="submit" className="btn btn-primary btn-block btn-lg" disabled={loading} style={{ marginTop: 8 }}>
            {loading ? <div className="spinner" /> : <>Sign In <ArrowRight size={18} /></>}
          </button>
        </form>

        <div className="divider-text">demo accounts</div>

        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={() => fillDemo("user")} className="btn btn-secondary btn-sm btn-block">Job Seeker</button>
          <button onClick={() => fillDemo("recruiter")} className="btn btn-secondary btn-sm btn-block">Recruiter</button>
        </div>

        <p style={{ textAlign: "center", marginTop: 28, fontSize: "0.9rem", color: "var(--text-secondary)" }}>
          Don't have an account?{" "}
          <Link to="/register" style={{ color: "var(--accent-violet)", fontWeight: 600 }}>
            Sign up free
          </Link>
        </p>
      </motion.div>
    </div>
  );
};

export default LoginPage;
