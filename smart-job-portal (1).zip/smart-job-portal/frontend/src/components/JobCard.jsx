import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { MapPin, Clock, IndianRupee, Users } from "lucide-react";
import { formatSalary, timeAgo, getInitials } from "../utils/helpers";

const jobTypeBadge = {
  "Full-time": "badge-indigo",
  "Part-time": "badge-cyan",
  Internship: "badge-amber",
  Contract: "badge-violet",
  Remote: "badge-emerald",
};

const JobCard = ({ job, index = 0 }) => {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.45, delay: Math.min(index * 0.06, 0.4), ease: [0.16, 1, 0.3, 1] }}
      className="card card-hover"
      style={{ padding: 24, display: "flex", flexDirection: "column", gap: 16, height: "100%" }}
      onClick={() => navigate(`/jobs/${job._id}`)}
    >
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
        <div style={{ display: "flex", gap: 12, alignItems: "center", minWidth: 0 }}>
          <div
            className="avatar"
            style={{
              width: 46,
              height: 46,
              fontSize: "1rem",
              borderRadius: 12,
              background: "var(--gradient-cool)",
              flexShrink: 0,
            }}
          >
            {getInitials(job.company)}
          </div>
          <div style={{ minWidth: 0 }}>
            <h3
              style={{
                fontSize: "1.02rem",
                fontWeight: 700,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {job.title}
            </h3>
            <p style={{ fontSize: "0.85rem", color: "var(--text-secondary)", fontWeight: 500 }}>{job.company}</p>
          </div>
        </div>
        <span className={`badge ${jobTypeBadge[job.jobType] || "badge-gray"}`} style={{ flexShrink: 0 }}>
          {job.jobType}
        </span>
      </div>

      <p
        style={{
          fontSize: "0.87rem",
          color: "var(--text-secondary)",
          lineHeight: 1.6,
          display: "-webkit-box",
          WebkitLineClamp: 2,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
        }}
      >
        {job.description}
      </p>

      <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
        {(job.skills || []).slice(0, 3).map((skill) => (
          <span key={skill} className="badge badge-gray">
            {skill}
          </span>
        ))}
        {job.skills?.length > 3 && <span className="badge badge-gray">+{job.skills.length - 3}</span>}
      </div>

      <div style={{ marginTop: "auto", paddingTop: 12, borderTop: "1px solid var(--border-subtle)", display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14, fontSize: "0.8rem", color: "var(--text-tertiary)", flexWrap: "wrap" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <MapPin size={13} /> {job.location}
          </span>
          <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
            <IndianRupee size={13} /> {formatSalary(job.salary)}
          </span>
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "var(--text-tertiary)" }}>
            <Clock size={12} /> {timeAgo(job.createdAt)}
          </span>
          <span style={{ display: "flex", alignItems: "center", gap: 5, fontSize: "0.78rem", color: "var(--text-tertiary)" }}>
            <Users size={12} /> {job.applicantsCount || 0} applied
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default JobCard;
