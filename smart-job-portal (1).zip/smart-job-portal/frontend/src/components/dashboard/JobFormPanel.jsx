import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import { X, Briefcase } from "lucide-react";
import { jobsAPI } from "../../api/jobs";
import { getErrorMessage } from "../../utils/helpers";

const JOB_TYPES = ["Full-time", "Part-time", "Internship", "Contract", "Remote"];

const emptyForm = {
  title: "",
  company: "",
  description: "",
  skills: "",
  location: "",
  jobType: "Full-time",
  experience: "",
  salaryMin: "",
  salaryMax: "",
};

const JobFormPanel = ({ onClose, onSuccess, editJob = null, defaultCompany = "" }) => {
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (editJob) {
      setForm({
        title: editJob.title || "",
        company: editJob.company || "",
        description: editJob.description || "",
        skills: (editJob.skills || []).join(", "),
        location: editJob.location || "",
        jobType: editJob.jobType || "Full-time",
        experience: editJob.experience || "",
        salaryMin: editJob.salary?.min || "",
        salaryMax: editJob.salary?.max || "",
      });
    } else if (defaultCompany) {
      setForm((f) => ({ ...f, company: defaultCompany }));
    }
  }, [editJob, defaultCompany]);

  const validate = () => {
    const errs = {};
    if (!form.title.trim()) errs.title = "Job title is required";
    if (!form.company.trim()) errs.company = "Company is required";
    if (!form.description.trim() || form.description.trim().length < 20)
      errs.description = "Description should be at least 20 characters";
    if (!form.location.trim()) errs.location = "Location is required";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitting(true);
    const payload = {
      title: form.title.trim(),
      company: form.company.trim(),
      description: form.description.trim(),
      skills: form.skills,
      location: form.location.trim(),
      jobType: form.jobType,
      experience: form.experience.trim() || "Not specified",
      salary: {
        min: Number(form.salaryMin) || 0,
        max: Number(form.salaryMax) || 0,
      },
    };

    try {
      if (editJob) {
        await jobsAPI.update(editJob._id, payload);
        toast.success("Job updated successfully");
      } else {
        await jobsAPI.create(payload);
        toast.success("Job posted successfully! 🎉");
      }
      onSuccess();
    } catch (err) {
      toast.error(getErrorMessage(err, "Failed to save job"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.6)",
        backdropFilter: "blur(4px)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.97 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="glass"
        style={{ width: "100%", maxWidth: 600, maxHeight: "88vh", overflowY: "auto", borderRadius: "var(--radius-lg)", padding: 32 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 11, background: "var(--gradient-primary)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Briefcase size={18} color="white" />
            </div>
            <h2 style={{ fontSize: "1.2rem" }}>{editJob ? "Edit Job" : "Post a New Job"}</h2>
          </div>
          <button onClick={onClose} className="btn btn-icon btn-secondary">
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Job Title</label>
              <input
                className={`form-input ${errors.title ? "error" : ""}`}
                placeholder="e.g. Senior Frontend Developer"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
              {errors.title && <span className="form-error">{errors.title}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Company</label>
              <input
                className={`form-input ${errors.company ? "error" : ""}`}
                placeholder="e.g. TechCorp Solutions"
                value={form.company}
                onChange={(e) => setForm({ ...form, company: e.target.value })}
              />
              {errors.company && <span className="form-error">{errors.company}</span>}
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Job Description</label>
            <textarea
              className={`form-textarea ${errors.description ? "error" : ""}`}
              placeholder="Describe the role, responsibilities, and what makes this opportunity exciting..."
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              rows={5}
            />
            {errors.description && <span className="form-error">{errors.description}</span>}
          </div>

          <div className="form-group">
            <label className="form-label">Required Skills (comma separated)</label>
            <input
              className="form-input"
              placeholder="React, Node.js, MongoDB"
              value={form.skills}
              onChange={(e) => setForm({ ...form, skills: e.target.value })}
            />
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Location</label>
              <input
                className={`form-input ${errors.location ? "error" : ""}`}
                placeholder="e.g. Bengaluru, India"
                value={form.location}
                onChange={(e) => setForm({ ...form, location: e.target.value })}
              />
              {errors.location && <span className="form-error">{errors.location}</span>}
            </div>
            <div className="form-group">
              <label className="form-label">Job Type</label>
              <select className="form-select" value={form.jobType} onChange={(e) => setForm({ ...form, jobType: e.target.value })}>
                {JOB_TYPES.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16 }}>
            <div className="form-group">
              <label className="form-label">Experience</label>
              <input
                className="form-input"
                placeholder="e.g. 2-4 years"
                value={form.experience}
                onChange={(e) => setForm({ ...form, experience: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Min Salary (₹/yr)</label>
              <input
                type="number"
                className="form-input"
                placeholder="600000"
                value={form.salaryMin}
                onChange={(e) => setForm({ ...form, salaryMin: e.target.value })}
              />
            </div>
            <div className="form-group">
              <label className="form-label">Max Salary (₹/yr)</label>
              <input
                type="number"
                className="form-input"
                placeholder="1200000"
                value={form.salaryMax}
                onChange={(e) => setForm({ ...form, salaryMax: e.target.value })}
              />
            </div>
          </div>

          <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
            <button type="button" onClick={onClose} className="btn btn-secondary btn-block">
              Cancel
            </button>
            <button type="submit" className="btn btn-primary btn-block" disabled={submitting}>
              {submitting ? <div className="spinner" /> : editJob ? "Update Job" : "Post Job"}
            </button>
          </div>
        </form>
      </motion.div>
    </motion.div>
  );
};

export default JobFormPanel;
