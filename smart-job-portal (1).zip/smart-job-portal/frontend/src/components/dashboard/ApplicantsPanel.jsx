import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import { X, Users, Mail, MapPin, CheckCircle2, XCircle, Clock, Hourglass } from "lucide-react";
import { applicationsAPI } from "../../api/applications";
import { getErrorMessage, getInitials, timeAgo, statusBadgeClass } from "../../utils/helpers";
import Loader from "../Loader";

const STATUS_OPTIONS = ["pending", "shortlisted", "accepted", "rejected"];
const statusIcon = { pending: Hourglass, shortlisted: Clock, accepted: CheckCircle2, rejected: XCircle };

const ApplicantsPanel = ({ job, onClose }) => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    const fetchApplicants = async () => {
      try {
        const res = await applicationsAPI.getJobApplications(job._id);
        setApplications(res.data.applications);
      } catch (err) {
        toast.error(getErrorMessage(err, "Failed to load applicants"));
      } finally {
        setLoading(false);
      }
    };
    fetchApplicants();
  }, [job._id]);

  const handleStatusChange = async (appId, status) => {
    setUpdatingId(appId);
    try {
      await applicationsAPI.updateStatus(appId, status);
      setApplications((prev) => prev.map((a) => (a._id === appId ? { ...a, status } : a)));
      toast.success("Status updated");
    } catch (err) {
      toast.error(getErrorMessage(err, "Failed to update status"));
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.6)",
        backdropFilter: "blur(4px)",
        zIndex: 200,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.97 }}
        transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
        className="glass"
        style={{ width: "100%", maxWidth: 700, maxHeight: "85vh", overflowY: "auto", borderRadius: "var(--radius-lg)", padding: 32 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 11, background: "var(--gradient-cool)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Users size={18} color="white" />
            </div>
            <div>
              <h2 style={{ fontSize: "1.15rem" }}>Applicants</h2>
              <p style={{ fontSize: "0.82rem", color: "var(--text-tertiary)" }}>{job.title}</p>
            </div>
          </div>
          <button onClick={onClose} className="btn btn-icon btn-secondary">
            <X size={18} />
          </button>
        </div>

        {loading ? (
          <Loader label="Loading applicants..." />
        ) : applications.length === 0 ? (
          <div className="empty-state">
            <Users size={44} strokeWidth={1.5} />
            <h3>No applicants yet</h3>
            <p>Once candidates apply, you'll see them here.</p>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {applications.map((app) => {
              const StatusIcon = statusIcon[app.status] || Hourglass;
              const applicant = app.userId;
              if (!applicant) return null;
              return (
                <div key={app._id} className="card" style={{ padding: 20 }}>
                  <div style={{ display: "flex", gap: 14, alignItems: "flex-start", flexWrap: "wrap" }}>
                    <div className="avatar" style={{ width: 44, height: 44, fontSize: "0.85rem", background: "var(--gradient-primary)" }}>
                      {getInitials(applicant.name)}
                    </div>
                    <div style={{ flex: 1, minWidth: 180 }}>
                      <div style={{ fontWeight: 700 }}>{applicant.name}</div>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 4, fontSize: "0.8rem", color: "var(--text-tertiary)" }}>
                        <span style={{ display: "flex", alignItems: "center", gap: 4 }}><Mail size={12} /> {applicant.email}</span>
                        {applicant.location && (
                          <span style={{ display: "flex", alignItems: "center", gap: 4 }}><MapPin size={12} /> {applicant.location}</span>
                        )}
                      </div>
                      {applicant.skills?.length > 0 && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                          {applicant.skills.slice(0, 5).map((s) => (
                            <span key={s} className="badge badge-gray">{s}</span>
                          ))}
                        </div>
                      )}
                      {app.coverNote && (
                        <p style={{ fontSize: "0.83rem", color: "var(--text-secondary)", marginTop: 10, fontStyle: "italic", lineHeight: 1.6 }}>
                          "{app.coverNote}"
                        </p>
                      )}
                      <div style={{ fontSize: "0.75rem", color: "var(--text-tertiary)", marginTop: 8 }}>
                        Applied {timeAgo(app.createdAt)}
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "flex-end" }}>
                      <span className={`badge ${statusBadgeClass(app.status)}`}>
                        <StatusIcon size={12} /> {app.status}
                      </span>
                      <select
                        className="form-select"
                        style={{ padding: "8px 32px 8px 12px", fontSize: "0.8rem" }}
                        value={app.status}
                        disabled={updatingId === app._id}
                        onChange={(e) => handleStatusChange(app._id, e.target.value)}
                      >
                        {STATUS_OPTIONS.map((s) => (
                          <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </motion.div>
    </motion.div>
  );
};

export default ApplicantsPanel;
