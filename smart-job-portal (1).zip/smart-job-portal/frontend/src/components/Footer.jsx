import { Link } from "react-router-dom";
import { Briefcase, Globe, Network, Code2, Mail } from "lucide-react";

const Footer = () => {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <Link to="/" style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16 }}>
              <div
                style={{
                  width: 34,
                  height: 34,
                  borderRadius: 10,
                  background: "var(--gradient-primary)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Briefcase size={16} color="white" />
              </div>
              <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.05rem" }}>
                Smart<span className="gradient-text">Job</span>
              </span>
            </Link>
            <p style={{ color: "var(--text-secondary)", fontSize: "0.9rem", maxWidth: 280, lineHeight: 1.6, marginBottom: 20 }}>
              The smarter way to find your next role or hire your next great employee. Built for modern careers.
            </p>
            <div style={{ display: "flex", gap: 10 }}>
              {[Globe, Network, Code2, Mail].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="glass"
                  style={{
                    width: 38,
                    height: 38,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    borderRadius: "var(--radius-full)",
                    color: "var(--text-secondary)",
                  }}
                >
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: "0.85rem", textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-tertiary)", marginBottom: 18 }}>
              Product
            </h4>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <Link to="/jobs" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Browse Jobs</Link>
              <Link to="/register" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Post a Job</Link>
              <Link to="/dashboard" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Dashboard</Link>
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: "0.85rem", textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-tertiary)", marginBottom: 18 }}>
              Company
            </h4>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>About Us</a>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Careers</a>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Blog</a>
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: "0.85rem", textTransform: "uppercase", letterSpacing: "0.04em", color: "var(--text-tertiary)", marginBottom: 18 }}>
              Legal
            </h4>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Privacy Policy</a>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Terms of Service</a>
              <a href="#" style={{ fontSize: "0.9rem", color: "var(--text-secondary)" }}>Cookie Policy</a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} SmartJob Portal. All rights reserved.</span>
          <span>Crafted with 💜 for ambitious careers.</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
