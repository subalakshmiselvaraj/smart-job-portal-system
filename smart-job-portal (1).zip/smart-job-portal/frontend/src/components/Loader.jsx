const Loader = ({ fullPage, label = "Loading..." }) => {
  return (
    <div className="page-loader" style={fullPage ? { minHeight: "70vh" } : {}}>
      <div className="spinner" />
      <span style={{ color: "var(--text-secondary)", fontSize: "0.9rem" }}>{label}</span>
    </div>
  );
};

export default Loader;
