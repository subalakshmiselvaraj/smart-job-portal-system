import { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Briefcase, Menu, X, LayoutDashboard, LogOut, ChevronDown } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getInitials } from "../utils/helpers";

const Navbar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setMenuOpen(false);
  }, [location.pathname]);

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const dashboardPath =
    user?.role === "recruiter" || user?.role === "admin" ? "/recruiter/dashboard" : "/dashboard";

  const navLinks = [
    { label: "Home", to: "/" },
    { label: "Jobs", to: "/jobs" },
  ];

  return (
    <header
      style={{
        position: "sticky",
        top: 0,
        zIndex: 100,
        transition: "all 0.3s ease",
        background: scrolled ? "rgba(10, 10, 15, 0.75)" : "transparent",
        backdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: scrolled ? "1px solid var(--border-subtle)" : "1px solid transparent",
      }}
    >
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 76 }}>
        <Link to="/" style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div
            style={{
              width: 38,
              height: 38,
              borderRadius: 11,
              background: "var(--gradient-primary)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              boxShadow: "0 4px 16px rgba(99,102,241,0.4)",
            }}
          >
            <Briefcase size={19} color="white" strokeWidth={2.3} />
          </div>
          <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "1.15rem", letterSpacing: "-0.02em" }}>
            Smart<span className="gradient-text">Job</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <nav style={{ display: "flex", alignItems: "center", gap: 36 }} className="navbar-desktop-links">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              style={{
                fontSize: "0.92rem",
                fontWeight: 500,
                color: location.pathname === link.to ? "var(--text-primary)" : "var(--text-secondary)",
                transition: "color 0.2s",
              }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div style={{ display: "flex", alignItems: "center", gap: 12 }} className="navbar-desktop-actions">
          {!user ? (
            <>
              <Link to="/login" className="btn btn-ghost btn-sm">
                Login
              </Link>
              <Link to="/register" className="btn btn-primary btn-sm">
                Get Started
              </Link>
            </>
          ) : (
            <div style={{ position: "relative" }}>
              <button
                onClick={() => setMenuOpen((o) => !o)}
                style={{ display: "flex", alignItems: "center", gap: 8, padding: "6px 12px 6px 6px", borderRadius: "var(--radius-full)", background: "var(--bg-card)", border: "1px solid var(--border-subtle)" }}
              >
                <div
                  className="avatar"
                  style={{ width: 32, height: 32, fontSize: "0.78rem", background: user.avatarColor || "var(--accent-violet)" }}
                >
                  {getInitials(user.name)}
                </div>
                <span style={{ fontSize: "0.88rem", fontWeight: 600 }}>{user.name.split(" ")[0]}</span>
                <ChevronDown size={15} color="var(--text-tertiary)" />
              </button>

              <AnimatePresence>
                {menuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -8, scale: 0.96 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -8, scale: 0.96 }}
                    transition={{ duration: 0.18 }}
                    className="glass"
                    style={{
                      position: "absolute",
                      right: 0,
                      top: "calc(100% + 10px)",
                      width: 220,
                      borderRadius: "var(--radius-md)",
                      padding: 8,
                      boxShadow: "var(--shadow-lg)",
                    }}
                  >
                    <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--border-subtle)", marginBottom: 6 }}>
                      <div style={{ fontWeight: 600, fontSize: "0.9rem" }}>{user.name}</div>
                      <div style={{ fontSize: "0.78rem", color: "var(--text-tertiary)" }}>{user.email}</div>
                      <span className={`badge badge-violet`} style={{ marginTop: 6 }}>
                        {user.role}
                      </span>
                    </div>
                    <Link
                      to={dashboardPath}
                      style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, fontSize: "0.88rem", fontWeight: 500 }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = "var(--bg-card-hover)")}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    >
                      <LayoutDashboard size={16} /> Dashboard
                    </Link>
                    <button
                      onClick={handleLogout}
                      style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, fontSize: "0.88rem", fontWeight: 500, width: "100%", color: "#f87171" }}
                      onMouseEnter={(e) => (e.currentTarget.style.background = "rgba(239,68,68,0.1)")}
                      onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
                    >
                      <LogOut size={16} /> Logout
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          )}
        </div>

        {/* Mobile toggle */}
        <button className="navbar-mobile-toggle" onClick={() => setMobileOpen((o) => !o)} style={{ display: "none" }}>
          {mobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            style={{ overflow: "hidden", borderTop: "1px solid var(--border-subtle)" }}
            className="navbar-mobile-menu"
          >
            <div className="container" style={{ display: "flex", flexDirection: "column", gap: 4, padding: "16px 24px 24px" }}>
              {navLinks.map((link) => (
                <Link key={link.to} to={link.to} className="btn-ghost" style={{ padding: "12px 8px", borderRadius: 10, fontWeight: 500 }}>
                  {link.label}
                </Link>
              ))}
              <div style={{ height: 1, background: "var(--border-subtle)", margin: "10px 0" }} />
              {!user ? (
                <>
                  <Link to="/login" className="btn btn-secondary btn-block">Login</Link>
                  <Link to="/register" className="btn btn-primary btn-block" style={{ marginTop: 8 }}>Get Started</Link>
                </>
              ) : (
                <>
                  <Link to={dashboardPath} className="btn btn-secondary btn-block">
                    <LayoutDashboard size={16} /> Dashboard
                  </Link>
                  <button onClick={handleLogout} className="btn btn-danger btn-block" style={{ marginTop: 8 }}>
                    <LogOut size={16} /> Logout
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Navbar;
