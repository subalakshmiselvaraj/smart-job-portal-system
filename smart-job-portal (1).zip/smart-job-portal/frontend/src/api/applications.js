import api from "./axios";

export const applicationsAPI = {
  apply: (data) => api.post("/apply", data),
  getUserApplications: () => api.get("/applications/user"),
  getJobApplications: (jobId) => api.get(`/applications/job/${jobId}`),
  updateStatus: (applicationId, status) =>
    api.put(`/applications/${applicationId}/status`, { status }),
};
