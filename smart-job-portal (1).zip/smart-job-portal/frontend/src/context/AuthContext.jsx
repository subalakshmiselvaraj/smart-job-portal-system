import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { authAPI } from "../api/auth";
import toast from "react-hot-toast";

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const initAuth = async () => {
      const token = localStorage.getItem("sjp_token");
      const cachedUser = localStorage.getItem("sjp_user");

      if (token && cachedUser) {
        try {
          setUser(JSON.parse(cachedUser));
          const res = await authAPI.getMe();
          setUser(res.data.user);
          localStorage.setItem("sjp_user", JSON.stringify(res.data.user));
        } catch {
          localStorage.removeItem("sjp_token");
          localStorage.removeItem("sjp_user");
          setUser(null);
        }
      }
      setLoading(false);
    };
    initAuth();
  }, []);

  const login = useCallback(async (email, password) => {
    const res = await authAPI.login({ email, password });
    const { token, user } = res.data;
    localStorage.setItem("sjp_token", token);
    localStorage.setItem("sjp_user", JSON.stringify(user));
    setUser(user);
    return user;
  }, []);

  const register = useCallback(async (payload) => {
    const res = await authAPI.register(payload);
    const { token, user } = res.data;
    localStorage.setItem("sjp_token", token);
    localStorage.setItem("sjp_user", JSON.stringify(user));
    setUser(user);
    return user;
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem("sjp_token");
    localStorage.removeItem("sjp_user");
    setUser(null);
    toast.success("Logged out successfully");
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within an AuthProvider");
  return ctx;
};
